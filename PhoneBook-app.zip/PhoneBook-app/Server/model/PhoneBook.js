const mongoose=require('mongoose');
const PhoneBookSchema = new mongoose.Schema({
  name:{
    type:String,
    require:true
  },
  phone:{
    type:Number,
    require:true
  }
})



//localhost:8000/add

//{
  // "name":"div",
  // "phone":"8072460998"
// }
const PhoneBook=mongoose.model('divya',PhoneBookSchema);
module.exports=PhoneBook;