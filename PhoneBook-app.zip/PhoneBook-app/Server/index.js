const express=require('express');
const mongoose=require('mongoose');
const PhoneBook=require('./model/PhoneBook');

const cors=require('cors');  
const app=express();
app.use(express.json());
app.use(cors());
const PORT=8000;
app.listen(PORT,()=>{
  console.log(`server is running this port ${PORT}...`)  //this is use to set the port
})

mongoose.connect('mongodb://localhost:27017/DB',
 { useNewUrlParser: true, useUnifiedTopology: true });
const db=mongoose.connection;
db.on('error',(error)=>{
  console.log('error to mongodb',error);
});
db.once('open',()=>{
  console.log('db connected');
});   //this is the database connecttion
  


app.post('/add',async(req,res)=>{
 
  console.log(req);
  const PhoneNumber=new PhoneBook(req.body)
  try{
await PhoneNumber.save()
res.status(201).json({
  status:'Success',
  data:{
    PhoneNumber
  }
})
  }
  
  catch(err){
res.status(500).json({
  status: 'Failed',
  message:err
})
}
})

app.get("/add",async(req,res)=>{
  console.log("the data is",req)

  const PhoneNumber=await PhoneBook.find();

  try{
   res.status(200).json({
      status:'Success',
      data:{
        PhoneNumber
      }
    })
      }
      
      catch(err){
    res.status(500).json({
      status: 'Failed',
      message:err
    })
    }
})
app.put('/add/:id', async (req,res) => {
  const updatedPhone = await PhoneBook.findByIdAndUpdate(req.params.id,req.body,{
      new : true,
      runValidators : true
    })
  try{
      res.status(200).json({
          status : 'Success',
          data : {
            updatedPhone
          }
        })
  }catch(err){
      console.log(err)
  }
})
app.delete('/add/:id', async(req,res) => {
  await PhoneBook.findByIdAndDelete(req.params.id)
  
  try{
    res.status(204).json({
        status : 'Success',
        data : {}
    })
  }catch(err){
      res.status(500).json({
          status: 'Failed',
          message : err
      })
  }
})


