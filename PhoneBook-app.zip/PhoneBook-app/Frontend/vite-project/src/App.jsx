import { useEffect, useState } from "react";

import axios from 'axios';

const App=()=>{
  const[name,setName]=useState(''); 
  const[phone,setPhone]=useState('');
  const[getDate,setDate]=useState([]);
  


useEffect(()=>{
  debugger
  axios.get('http://localhost:8000/add')
  .then(response=>{
    console.log("the response data",response.data);
    setDate(response.data.data.PhoneNumber);
  })
  .catch(err=>{
    console.log("the err in get data");
  })
},[])


const handleName=(event)=>{
setName(event.target.value)
}

  const handlePhone=(event)=>{
    setPhone(event.target.value);
  }


  const handleSubmit = () => {
    debugger;
  
    axios.post('http://localhost:8000/add', { name, phone })
      .then(response => {
        console.log(response.data);
       setName('')
      })
      .catch(error => {
        console.error('Error adding data:', error);
      });
  }
  

 
  
  return(
    <>
    <input type="text" placeholder="Enter Your Name" onChange={handleName}/>
    <input type="number" placeholder="Enter Your Phoneno" onChange={handlePhone}/>
    <button onClick={handleSubmit}>ADD</button>
    <div className="divContainer">

  <table>
    <thead>
      <tr>
        <th className="table-Heading">Name</th>
        <th  className="table-Heading">PhoneNo</th>
      </tr>
    </thead>
    <tbody>
      {

getDate.map((item,key)=>{
  return(
    <tr key={key}>
      <td className="table-Data">{item.name}</td>
      <td className="table-Data">{item.phone}</td>
      <button className="updateButton">Update</button>
      
    </tr>
  )
})

      }
      </tbody>
  </table>
    </div>
   
    
    </>
  )
}
export default App;